package registrationloginapp;

import java.util.Scanner;
import java.util.regex.Pattern;

public class RegistrationLogin {

    private String username;
    private String password;
    private Scanner input = new Scanner(System.in);

    public String registration() {
        StringBuilder result = new StringBuilder();

        System.out.println("Enter username:");
        username = input.nextLine();

        System.out.println("Enter password:");
        password = input.nextLine();

        System.out.println("Enter cell phone number(+27XXXXXXXXX):");
        String phoneNumber = input.nextLine();

        if (checkUserName(username)) {
            result.append("Username successfully captured\n");
        } else {
            result.append("Username is not correctly formatted, please ensure that the username contains an underscore and is more than 5 characters.\n");
        }

        if (checkPasswordComplexity(password)) {
            result.append("Password successfully captured\n");
        } else {
            result.append("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.\n");
        }

        if (checkCellPhoneNumber(phoneNumber)) {
            result.append("Cell phone number successfully captured\n");
        } else {
            result.append("Cell phone number is not correctly formatted or does not contain an international code, please correct the number and try again.\n");
        }

        return result.toString();
    }

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() > 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        boolean length = password.length() >= 8;
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasDigit = password.matches(".*[0-9].*");
        boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");
        return length && hasUpper && hasDigit && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String phoneNumber) {
        String pattern = "\\+27[6-9][0-9]{8}$";
        return Pattern.matches(pattern, phoneNumber);
    }

    public boolean login(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    public boolean loginPrompt() {
        System.out.println("Enter username:");
        String enteredUsername = input.nextLine();

        System.out.println("Enter password:");
        String enteredPassword = input.nextLine();

        return login(enteredUsername, enteredPassword);
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Successful login";
        } else {
            return "Failed login";
        }
    }
}
