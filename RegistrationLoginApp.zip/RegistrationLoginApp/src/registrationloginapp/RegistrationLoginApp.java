package registrationloginapp;

public class RegistrationLoginApp {

    public static void main(String[] args) {
        RegistrationLogin user = new RegistrationLogin();

        System.out.println("REGISTRATION");
        System.out.print(user.registration());

        System.out.println("LOGIN");
        boolean loginStatus = user.loginPrompt();
        System.out.println(user.returnLoginStatus(loginStatus));
    }
}
